SELECT  @@Servername as Servername,
        @@Version as Version,
        @@Language as Language,
        @@DateFirst as DateFirst,
        @@OPTIONS as Options